"""Text perturbations for toxicity robustness evaluation."""

from __future__ import annotations

import random
import re


TOKEN_RE = re.compile(r"[A-Za-z][A-Za-z']{2,}")

CHAR_SUBS = {
    "a": "@",
    "e": "3",
    "i": "1",
    "o": "0",
    "s": "$",
    "t": "7",
}

PREFERRED_CUE_WORDS = {
    "awful",
    "bad",
    "bigot",
    "coward",
    "crazy",
    "disgusting",
    "dumb",
    "fool",
    "garbage",
    "hate",
    "hateful",
    "idiot",
    "liar",
    "loser",
    "moron",
    "nasty",
    "racist",
    "ridiculous",
    "stupid",
    "trash",
    "ugly",
}

IDENTITY_SWAPS = {
    "woman": "man",
    "women": "men",
    "man": "woman",
    "men": "women",
    "muslim": "christian",
    "muslims": "christians",
    "christian": "muslim",
    "christians": "muslims",
    "black": "white",
    "white": "black",
    "gay": "straight",
    "straight": "gay",
}


def _tokens(text: str) -> list[re.Match[str]]:
    return list(TOKEN_RE.finditer(text))


def _choose_token(text: str, rng: random.Random, require_sub_char: bool = False) -> re.Match[str] | None:
    candidates = _tokens(text)
    if require_sub_char:
        candidates = [m for m in candidates if any(ch.lower() in CHAR_SUBS for ch in m.group(0))]
    if not candidates:
        return None
    preferred = [
        m for m in candidates
        if m.group(0).lower().strip("'") in PREFERRED_CUE_WORDS
    ]
    return rng.choice(preferred or candidates)


def _replace_span(text: str, match: re.Match[str], replacement: str) -> str:
    return text[: match.start()] + replacement + text[match.end() :]


def typo(text: str, rng: random.Random) -> str:
    match = _choose_token(text, rng)
    if match is None:
        return text
    token = match.group(0)
    if len(token) < 4:
        return text
    idx = rng.randint(1, len(token) - 2)
    chars = list(token)
    chars[idx], chars[idx + 1] = chars[idx + 1], chars[idx]
    return _replace_span(text, match, "".join(chars))


def char_substitution(text: str, rng: random.Random) -> str:
    match = _choose_token(text, rng, require_sub_char=True)
    if match is None:
        return text
    token = match.group(0)
    chars = list(token)
    replaceable = [i for i, ch in enumerate(chars) if ch.lower() in CHAR_SUBS]
    if not replaceable:
        return text
    idx = rng.choice(replaceable)
    chars[idx] = CHAR_SUBS[chars[idx].lower()]
    return _replace_span(text, match, "".join(chars))


def spacing(text: str, rng: random.Random) -> str:
    match = _choose_token(text, rng)
    if match is None:
        return text
    token = match.group(0)
    if len(token) < 4:
        return text
    return _replace_span(text, match, " ".join(token))


def repetition(text: str, rng: random.Random) -> str:
    match = _choose_token(text, rng)
    if match is None:
        return text
    token = match.group(0)
    chars = list(token)
    vowels = [i for i, ch in enumerate(chars) if ch.lower() in "aeiou"]
    idx = rng.choice(vowels) if vowels else rng.randint(0, len(chars) - 1)
    chars[idx] = chars[idx] * 3
    return _replace_span(text, match, "".join(chars))


def punctuation_noise(text: str, rng: random.Random) -> str:
    match = _choose_token(text, rng)
    if match is None:
        return text + "!!!"
    noises = ["!!!", "...", "?!", "??", "!!"]
    token = match.group(0) + rng.choice(noises)
    return _replace_span(text, match, token)


def case_change(text: str, rng: random.Random) -> str:
    match = _choose_token(text, rng)
    if match is None:
        return text
    token = match.group(0)
    changed = "".join(ch.upper() if i % 2 == 0 else ch.lower() for i, ch in enumerate(token))
    return _replace_span(text, match, changed)


def identity_swap(text: str, rng: random.Random) -> str:
    pattern = re.compile(r"\b(" + "|".join(map(re.escape, IDENTITY_SWAPS.keys())) + r")\b", re.IGNORECASE)
    matches = list(pattern.finditer(text))
    if not matches:
        return text
    match = rng.choice(matches)
    original = match.group(0)
    replacement = IDENTITY_SWAPS[original.lower()]
    if original[:1].isupper():
        replacement = replacement.capitalize()
    return _replace_span(text, match, replacement)


def combined(text: str, rng: random.Random) -> str:
    text = char_substitution(text, rng)
    return spacing(text, rng)


PERTURBATION_FUNCS = {
    "typo": typo,
    "char_substitution": char_substitution,
    "spacing": spacing,
    "repetition": repetition,
    "punctuation_noise": punctuation_noise,
    "case_change": case_change,
    "identity_swap": identity_swap,
    "combined": combined,
}


def perturb(text: str, perturbation_type: str, seed: int = 0) -> str:
    if perturbation_type not in PERTURBATION_FUNCS:
        raise ValueError(f"Unknown perturbation type: {perturbation_type}")
    rng = random.Random(seed)
    return PERTURBATION_FUNCS[perturbation_type](text, rng)
