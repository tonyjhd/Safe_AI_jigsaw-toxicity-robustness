#!/usr/bin/env python3
"""Train TF-IDF+MLP baselines and evaluate text perturbation robustness."""

from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.decomposition import TruncatedSVD
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, roc_auc_score
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from perturbations import PERTURBATION_FUNCS, perturb


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-csv", type=Path, default=Path("data/processed/jigsaw_subset.csv"))
    parser.add_argument("--output-dir", type=Path, default=Path("outputs"))
    parser.add_argument(
        "--models",
        nargs="+",
        default=["word_mlp", "char_mlp"],
        choices=["word_mlp", "char_mlp"],
    )
    parser.add_argument(
        "--perturbations",
        nargs="+",
        default=["typo", "char_substitution", "spacing", "repetition", "punctuation_noise", "combined"],
        choices=sorted(PERTURBATION_FUNCS),
    )
    parser.add_argument("--max-features", type=int, default=50_000)
    parser.add_argument("--svd-components", type=int, default=128)
    parser.add_argument("--hidden-size", type=int, default=64)
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--save-models", action="store_true")
    parser.add_argument(
        "--train-variants",
        nargs="+",
        default=["clean"],
        choices=["clean", "augmented"],
        help="clean trains on original texts only; augmented adds perturbed copies to the training set.",
    )
    parser.add_argument(
        "--augmentation-perturbations",
        nargs="+",
        default=["typo", "char_substitution", "spacing", "repetition", "combined"],
        choices=sorted(PERTURBATION_FUNCS),
    )
    parser.add_argument(
        "--augmentation-copies",
        type=int,
        default=1,
        help="Number of perturbed copies to add per original training row.",
    )
    parser.add_argument(
        "--augmentation-fraction",
        type=float,
        default=1.0,
        help="Fraction of training rows to augment for each augmented copy.",
    )
    return parser.parse_args()


def make_pipeline(model_name: str, args: argparse.Namespace) -> Pipeline:
    if model_name == "word_mlp":
        vectorizer = TfidfVectorizer(
            analyzer="word",
            ngram_range=(1, 2),
            max_features=args.max_features,
            min_df=2,
            max_df=0.95,
            lowercase=True,
            strip_accents="unicode",
        )
    elif model_name == "char_mlp":
        vectorizer = TfidfVectorizer(
            analyzer="char_wb",
            ngram_range=(3, 5),
            max_features=args.max_features,
            min_df=2,
            max_df=0.95,
            lowercase=True,
            strip_accents="unicode",
        )
    else:
        raise ValueError(model_name)

    return Pipeline(
        steps=[
            ("tfidf", vectorizer),
            ("svd", TruncatedSVD(n_components=args.svd_components, random_state=args.seed)),
            ("scale", StandardScaler()),
            (
                "mlp",
                MLPClassifier(
                    hidden_layer_sizes=(args.hidden_size,),
                    activation="relu",
                    solver="adam",
                    alpha=1e-4,
                    batch_size=128,
                    learning_rate_init=1e-3,
                    max_iter=args.epochs,
                    early_stopping=True,
                    n_iter_no_change=3,
                    random_state=args.seed,
                    verbose=False,
                ),
            ),
        ]
    )


def metrics(y_true: np.ndarray, proba: np.ndarray) -> dict[str, float]:
    pred = (proba >= 0.5).astype(int)
    out = {
        "accuracy": accuracy_score(y_true, pred),
        "precision": precision_score(y_true, pred, zero_division=0),
        "recall": recall_score(y_true, pred, zero_division=0),
        "f1": f1_score(y_true, pred, zero_division=0),
    }
    try:
        out["auroc"] = roc_auc_score(y_true, proba)
    except ValueError:
        out["auroc"] = float("nan")
    return out


def predict_proba_positive(model: Pipeline, texts: pd.Series) -> np.ndarray:
    proba = model.predict_proba(texts)
    return np.asarray(proba[:, 1])


def make_training_frame(train_df: pd.DataFrame, variant: str, args: argparse.Namespace) -> pd.DataFrame:
    if variant == "clean":
        return train_df[["comment_text", "label"]].copy()
    if variant != "augmented":
        raise ValueError(f"Unknown train variant: {variant}")
    if not 0 < args.augmentation_fraction <= 1:
        raise ValueError("--augmentation-fraction must be in (0, 1].")

    rng = random.Random(args.seed)
    base = train_df[["comment_text", "label"]].copy()
    augmented_parts = [base]

    source_df = train_df[["comment_text", "label"]].copy()
    if args.augmentation_fraction < 1.0:
        source_df = (
            source_df
            .groupby("label", group_keys=False)
            .sample(frac=args.augmentation_fraction, random_state=args.seed)
            .reset_index(drop=True)
        )

    texts = source_df["comment_text"].astype(str).tolist()
    labels = source_df["label"].astype(int).tolist()
    for copy_idx in range(args.augmentation_copies):
        perturbed_texts = []
        perturbation_types = []
        for row_idx, text in enumerate(texts):
            perturbation_type = rng.choice(args.augmentation_perturbations)
            perturbation_types.append(perturbation_type)
            perturbed_texts.append(
                perturb(text, perturbation_type, seed=args.seed + copy_idx * len(texts) + row_idx)
            )
        augmented_parts.append(
            pd.DataFrame(
                {
                    "comment_text": perturbed_texts,
                    "label": labels,
                    "augmentation_type": perturbation_types,
                }
            )
        )

    out = pd.concat(augmented_parts, ignore_index=True)
    out = out.sample(frac=1.0, random_state=args.seed).reset_index(drop=True)
    return out


def evaluate_model(
    model_name: str,
    model: Pipeline,
    test_df: pd.DataFrame,
    args: argparse.Namespace,
) -> tuple[list[dict[str, object]], pd.DataFrame]:
    y_test = test_df["label"].to_numpy(dtype=int)
    clean_proba = predict_proba_positive(model, test_df["comment_text"])
    clean_pred = (clean_proba >= 0.5).astype(int)
    clean_correct = clean_pred == y_test

    clean_metrics = metrics(y_test, clean_proba)
    rows: list[dict[str, object]] = [
        {
            "model": model_name,
            "test_type": "clean",
            "perturbation": "clean",
            "robustness_drop_f1": 0.0,
            "attack_success_rate": 0.0,
            "confidence_shift": 0.0,
            **clean_metrics,
        }
    ]

    failures = []
    for perturbation_type in args.perturbations:
        perturbed_texts = [
            perturb(text, perturbation_type, seed=args.seed + i)
            for i, text in enumerate(test_df["comment_text"].astype(str).tolist())
        ]
        pert_proba = predict_proba_positive(model, pd.Series(perturbed_texts))
        pert_pred = (pert_proba >= 0.5).astype(int)
        pert_metrics = metrics(y_test, pert_proba)

        clean_correct_count = int(clean_correct.sum())
        attack_success = int((clean_correct & (pert_pred != y_test)).sum())
        asr = attack_success / clean_correct_count if clean_correct_count else 0.0
        confidence_shift = float(np.mean(np.abs(clean_proba - pert_proba)))

        rows.append(
            {
                "model": model_name,
                "test_type": "perturbed",
                "perturbation": perturbation_type,
                "robustness_drop_f1": clean_metrics["f1"] - pert_metrics["f1"],
                "attack_success_rate": asr,
                "confidence_shift": confidence_shift,
                **pert_metrics,
            }
        )

        fail_idx = np.where(clean_correct & (pert_pred != y_test))[0][:25]
        for idx in fail_idx:
            failures.append(
                {
                    "model": model_name,
                    "perturbation": perturbation_type,
                    "row_index": int(test_df.index[idx]),
                    "label": int(y_test[idx]),
                    "clean_probability": float(clean_proba[idx]),
                    "perturbed_probability": float(pert_proba[idx]),
                    "clean_prediction": int(clean_pred[idx]),
                    "perturbed_prediction": int(pert_pred[idx]),
                }
            )

    return rows, pd.DataFrame(failures)


def main() -> None:
    args = parse_args()
    reports_dir = args.output_dir / "reports"
    models_dir = args.output_dir / "models"
    reports_dir.mkdir(parents=True, exist_ok=True)
    models_dir.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(args.input_csv)
    required = {"comment_text", "label", "split"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")

    train_df = df[df["split"] == "train"].copy()
    val_df = df[df["split"] == "val"].copy()
    test_df = df[df["split"] == "test"].copy()
    train_full = pd.concat([train_df, val_df], ignore_index=True)

    all_rows: list[dict[str, object]] = []
    all_failures = []
    run_info = {
        "input_csv": str(args.input_csv),
        "train_rows": int(len(train_df)),
        "val_rows": int(len(val_df)),
        "test_rows": int(len(test_df)),
        "models": args.models,
        "train_variants": args.train_variants,
        "perturbations": args.perturbations,
        "augmentation_perturbations": args.augmentation_perturbations,
        "augmentation_copies": args.augmentation_copies,
        "augmentation_fraction": args.augmentation_fraction,
        "max_features": args.max_features,
        "svd_components": args.svd_components,
        "hidden_size": args.hidden_size,
        "epochs": args.epochs,
        "seed": args.seed,
    }

    for model_name in args.models:
        for train_variant in args.train_variants:
            display_name = f"{model_name}_{train_variant}"
            train_variant_df = make_training_frame(train_full, train_variant, args)
            print(f"Training {display_name} on {len(train_variant_df)} rows...")
            model = make_pipeline(model_name, args)
            model.fit(train_variant_df["comment_text"], train_variant_df["label"].astype(int))
            rows, failures = evaluate_model(display_name, model, test_df, args)
            all_rows.extend(rows)
            if not failures.empty:
                all_failures.append(failures)
            if args.save_models:
                joblib.dump(model, models_dir / f"{display_name}.joblib")

    metrics_df = pd.DataFrame(all_rows)
    metrics_path = reports_dir / "robustness_metrics.csv"
    metrics_df.to_csv(metrics_path, index=False)

    if all_failures:
        failure_df = pd.concat(all_failures, ignore_index=True)
    else:
        failure_df = pd.DataFrame()
    failure_path = reports_dir / "failure_cases_metadata.csv"
    failure_df.to_csv(failure_path, index=False)

    (reports_dir / "run_info.json").write_text(json.dumps(run_info, indent=2), encoding="utf-8")
    print(metrics_df.to_string(index=False))
    print(f"\nSaved metrics to {metrics_path}")
    print(f"Saved failure metadata to {failure_path}")


if __name__ == "__main__":
    main()
