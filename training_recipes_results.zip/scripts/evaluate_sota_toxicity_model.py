#!/usr/bin/env python3
"""Evaluate a Hugging Face toxicity model on clean and perturbed Jigsaw comments."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, roc_auc_score

from perturbations import PERTURBATION_FUNCS, perturb


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-csv", type=Path, default=Path("data/processed/jigsaw_subset_14k_stratified.csv"))
    parser.add_argument("--output-dir", type=Path, default=Path("outputs/sota_unbiased_roberta"))
    parser.add_argument("--model-id", default="unitary/unbiased-toxic-roberta")
    parser.add_argument(
        "--perturbations",
        nargs="+",
        default=["typo", "char_substitution", "spacing", "repetition", "punctuation_noise", "combined"],
        choices=sorted(PERTURBATION_FUNCS),
    )
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--max-length", type=int, default=192)
    parser.add_argument("--max-samples", type=int, default=0, help="0 means use the full test split.")
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


def metrics(y_true: np.ndarray, proba: np.ndarray) -> dict[str, float]:
    pred = (proba >= 0.5).astype(int)
    out = {
        "accuracy": accuracy_score(y_true, pred),
        "precision": precision_score(y_true, pred, zero_division=0),
        "recall": recall_score(y_true, pred, zero_division=0),
        "f1": f1_score(y_true, pred, zero_division=0),
    }
    try:
        out["auroc"] = roc_auc_score(y_true, proba)
    except ValueError:
        out["auroc"] = float("nan")
    return out


def pick_toxicity_scores(logits: torch.Tensor, id2label: dict[int, str]) -> np.ndarray:
    """Return one toxicity probability per row for common HF classifier layouts."""
    label_map = {int(k): str(v).lower() for k, v in id2label.items()}

    if logits.shape[1] == 1:
        return torch.sigmoid(logits[:, 0]).cpu().numpy()

    toxic_indices = [
        idx
        for idx, label in label_map.items()
        if label in {"toxic", "toxicity"} or label.endswith("toxic") or "toxicity" in label
    ]
    non_toxic_indices = [
        idx
        for idx, label in label_map.items()
        if "non" in label and ("toxic" in label or "toxicity" in label)
    ]

    if toxic_indices:
        if len(toxic_indices) == 1:
            probs = torch.sigmoid(logits) if logits.shape[1] > 2 else torch.softmax(logits, dim=1)
            return probs[:, toxic_indices[0]].cpu().numpy()
        probs = torch.sigmoid(logits)
        return probs[:, toxic_indices].max(dim=1).values.cpu().numpy()

    if logits.shape[1] == 2 and non_toxic_indices:
        toxic_idx = 1 - non_toxic_indices[0]
        return torch.softmax(logits, dim=1)[:, toxic_idx].cpu().numpy()

    if logits.shape[1] == 2:
        return torch.softmax(logits, dim=1)[:, 1].cpu().numpy()

    return torch.sigmoid(logits).max(dim=1).values.cpu().numpy()


def predict_scores(model, tokenizer, texts: list[str], args: argparse.Namespace, device: torch.device) -> np.ndarray:
    scores = []
    model.eval()
    with torch.no_grad():
        for start in range(0, len(texts), args.batch_size):
            batch = texts[start : start + args.batch_size]
            encoded = tokenizer(
                batch,
                padding=True,
                truncation=True,
                max_length=args.max_length,
                return_tensors="pt",
            )
            encoded = {key: value.to(device) for key, value in encoded.items()}
            logits = model(**encoded).logits
            scores.append(pick_toxicity_scores(logits, model.config.id2label))
    return np.concatenate(scores)


def evaluate(args: argparse.Namespace) -> pd.DataFrame:
    from transformers import AutoModelForSequenceClassification, AutoTokenizer

    df = pd.read_csv(args.input_csv)
    test_df = df[df["split"] == "test"].copy()
    if args.max_samples and args.max_samples < len(test_df):
        test_df = (
            test_df
            .groupby("label", group_keys=False)
            .sample(n=args.max_samples // 2, random_state=args.seed)
            .sample(frac=1, random_state=args.seed)
            .reset_index(drop=True)
        )

    device = torch.device("mps" if torch.backends.mps.is_available() else "cpu")
    print(f"Using device: {device}")
    print(f"Loading SOTA reference model: {args.model_id}")
    tokenizer = AutoTokenizer.from_pretrained(args.model_id)
    model = AutoModelForSequenceClassification.from_pretrained(args.model_id).to(device)
    print(f"id2label={model.config.id2label}")
    print(f"Evaluating {len(test_df)} test rows")

    y = test_df["label"].astype(int).to_numpy()
    clean_texts = test_df["comment_text"].astype(str).tolist()
    clean_proba = predict_scores(model, tokenizer, clean_texts, args, device)
    clean_pred = (clean_proba >= 0.5).astype(int)
    clean_correct = clean_pred == y
    clean_metrics = metrics(y, clean_proba)

    rows: list[dict[str, object]] = [
        {
            "model": args.model_id,
            "test_type": "clean",
            "perturbation": "clean",
            "robustness_drop_f1": 0.0,
            "attack_success_rate": 0.0,
            "confidence_shift": 0.0,
            **clean_metrics,
        }
    ]

    for perturbation_type in args.perturbations:
        perturbed_texts = [
            perturb(text, perturbation_type, seed=args.seed + idx)
            for idx, text in enumerate(clean_texts)
        ]
        pert_proba = predict_scores(model, tokenizer, perturbed_texts, args, device)
        pert_pred = (pert_proba >= 0.5).astype(int)
        pert_metrics = metrics(y, pert_proba)
        clean_correct_count = int(clean_correct.sum())
        attack_success = int((clean_correct & (pert_pred != y)).sum())
        rows.append(
            {
                "model": args.model_id,
                "test_type": "perturbed",
                "perturbation": perturbation_type,
                "robustness_drop_f1": clean_metrics["f1"] - pert_metrics["f1"],
                "attack_success_rate": attack_success / clean_correct_count if clean_correct_count else 0.0,
                "confidence_shift": float(np.mean(np.abs(clean_proba - pert_proba))),
                **pert_metrics,
            }
        )

    return pd.DataFrame(rows)


def main() -> None:
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    args = parse_args()
    reports_dir = args.output_dir / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)
    metrics_df = evaluate(args)
    out_path = reports_dir / "robustness_metrics.csv"
    metrics_df.to_csv(out_path, index=False)
    (reports_dir / "run_info.json").write_text(json.dumps(vars(args), indent=2, default=str), encoding="utf-8")
    print(metrics_df.to_string(index=False))
    print(f"Saved SOTA metrics to {out_path}")


if __name__ == "__main__":
    main()
