#!/usr/bin/env python3
"""Train a lightweight PyTorch TextCNN and evaluate perturbation robustness."""

from __future__ import annotations

import argparse
import json
import random
import re
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, roc_auc_score
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

from perturbations import PERTURBATION_FUNCS, perturb


TOKEN_RE = re.compile(r"[A-Za-z']+|\d+|[^\w\s]")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-csv", type=Path, default=Path("data/processed/jigsaw_subset_14k_stratified.csv"))
    parser.add_argument("--output-dir", type=Path, default=Path("outputs/textcnn"))
    parser.add_argument("--train-variants", nargs="+", default=["clean", "augmented"], choices=["clean", "augmented"])
    parser.add_argument("--augmentation-fraction", type=float, default=0.25)
    parser.add_argument(
        "--augmentation-perturbations",
        nargs="+",
        default=["typo", "char_substitution", "spacing", "repetition", "combined"],
        choices=sorted(PERTURBATION_FUNCS),
    )
    parser.add_argument(
        "--perturbations",
        nargs="+",
        default=["typo", "char_substitution", "spacing", "repetition", "punctuation_noise", "combined"],
        choices=sorted(PERTURBATION_FUNCS),
    )
    parser.add_argument("--max-vocab-size", type=int, default=30_000)
    parser.add_argument("--max-len", type=int, default=128)
    parser.add_argument("--embedding-dim", type=int, default=64)
    parser.add_argument("--filters", type=int, default=64)
    parser.add_argument("--dropout", type=float, default=0.5)
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--epochs", type=int, default=4)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--save-models", action="store_true")
    return parser.parse_args()


def tokenize(text: str) -> list[str]:
    return [token.lower() for token in TOKEN_RE.findall(str(text))]


def build_vocab(texts: list[str], max_vocab_size: int) -> dict[str, int]:
    counter: Counter[str] = Counter()
    for text in texts:
        counter.update(tokenize(text))
    vocab = {"<pad>": 0, "<unk>": 1}
    for token, _ in counter.most_common(max_vocab_size - len(vocab)):
        vocab[token] = len(vocab)
    return vocab


def encode_texts(texts: list[str], vocab: dict[str, int], max_len: int) -> torch.Tensor:
    encoded = np.zeros((len(texts), max_len), dtype=np.int64)
    unk = vocab["<unk>"]
    for row_idx, text in enumerate(texts):
        ids = [vocab.get(token, unk) for token in tokenize(text)[:max_len]]
        encoded[row_idx, : len(ids)] = ids
    return torch.from_numpy(encoded)


class TextCNN(nn.Module):
    def __init__(self, vocab_size: int, embedding_dim: int, filters: int, dropout: float) -> None:
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=0)
        self.convs = nn.ModuleList(
            [nn.Conv1d(embedding_dim, filters, kernel_size=k) for k in [3, 4, 5]]
        )
        self.dropout = nn.Dropout(dropout)
        self.fc = nn.Linear(filters * len(self.convs), 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.embedding(x).transpose(1, 2)
        pooled = []
        for conv in self.convs:
            h = torch.relu(conv(x))
            pooled.append(torch.max(h, dim=2).values)
        h = torch.cat(pooled, dim=1)
        h = self.dropout(h)
        return self.fc(h).squeeze(1)


def make_training_frame(train_df: pd.DataFrame, variant: str, args: argparse.Namespace) -> pd.DataFrame:
    base = train_df[["comment_text", "label"]].copy()
    if variant == "clean":
        return base
    if variant != "augmented":
        raise ValueError(variant)

    source = (
        base
        .groupby("label", group_keys=False)
        .sample(frac=args.augmentation_fraction, random_state=args.seed)
        .reset_index(drop=True)
    )
    rng = random.Random(args.seed)
    texts = []
    for idx, text in enumerate(source["comment_text"].astype(str).tolist()):
        ptype = rng.choice(args.augmentation_perturbations)
        texts.append(perturb(text, ptype, seed=args.seed + idx))
    augmented = pd.DataFrame({"comment_text": texts, "label": source["label"].astype(int).tolist()})
    return pd.concat([base, augmented], ignore_index=True).sample(frac=1, random_state=args.seed)


def metrics(y_true: np.ndarray, proba: np.ndarray) -> dict[str, float]:
    pred = (proba >= 0.5).astype(int)
    return {
        "accuracy": accuracy_score(y_true, pred),
        "precision": precision_score(y_true, pred, zero_division=0),
        "recall": recall_score(y_true, pred, zero_division=0),
        "f1": f1_score(y_true, pred, zero_division=0),
        "auroc": roc_auc_score(y_true, proba),
    }


def predict(model: TextCNN, texts: list[str], vocab: dict[str, int], args: argparse.Namespace, device: torch.device) -> np.ndarray:
    model.eval()
    x = encode_texts(texts, vocab, args.max_len)
    loader = DataLoader(TensorDataset(x), batch_size=args.batch_size)
    probs = []
    with torch.no_grad():
        for (batch_x,) in loader:
            logits = model(batch_x.to(device))
            probs.append(torch.sigmoid(logits).cpu().numpy())
    return np.concatenate(probs)


def train_model(train_df: pd.DataFrame, vocab: dict[str, int], args: argparse.Namespace, device: torch.device) -> TextCNN:
    x = encode_texts(train_df["comment_text"].astype(str).tolist(), vocab, args.max_len)
    y = torch.tensor(train_df["label"].astype(float).to_numpy(), dtype=torch.float32)
    loader = DataLoader(TensorDataset(x, y), batch_size=args.batch_size, shuffle=True)
    model = TextCNN(len(vocab), args.embedding_dim, args.filters, args.dropout).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    loss_fn = nn.BCEWithLogitsLoss()

    for epoch in range(args.epochs):
        model.train()
        losses = []
        for batch_x, batch_y in loader:
            batch_x = batch_x.to(device)
            batch_y = batch_y.to(device)
            optimizer.zero_grad()
            loss = loss_fn(model(batch_x), batch_y)
            loss.backward()
            optimizer.step()
            losses.append(float(loss.item()))
        print(f"epoch={epoch + 1} loss={np.mean(losses):.4f}")
    return model


def evaluate_variant(
    model_name: str,
    model: TextCNN,
    vocab: dict[str, int],
    test_df: pd.DataFrame,
    args: argparse.Namespace,
    device: torch.device,
) -> list[dict[str, object]]:
    y = test_df["label"].astype(int).to_numpy()
    clean_texts = test_df["comment_text"].astype(str).tolist()
    clean_proba = predict(model, clean_texts, vocab, args, device)
    clean_pred = clean_proba >= 0.5
    clean_correct = clean_pred == y
    clean_metrics = metrics(y, clean_proba)

    rows = [
        {
            "model": model_name,
            "test_type": "clean",
            "perturbation": "clean",
            "robustness_drop_f1": 0.0,
            "attack_success_rate": 0.0,
            "confidence_shift": 0.0,
            **clean_metrics,
        }
    ]
    for perturbation_type in args.perturbations:
        perturbed = [
            perturb(text, perturbation_type, seed=args.seed + idx)
            for idx, text in enumerate(clean_texts)
        ]
        pert_proba = predict(model, perturbed, vocab, args, device)
        pert_pred = pert_proba >= 0.5
        pert_metrics = metrics(y, pert_proba)
        clean_correct_count = int(clean_correct.sum())
        attack_success = int((clean_correct & (pert_pred != y)).sum())
        rows.append(
            {
                "model": model_name,
                "test_type": "perturbed",
                "perturbation": perturbation_type,
                "robustness_drop_f1": clean_metrics["f1"] - pert_metrics["f1"],
                "attack_success_rate": attack_success / clean_correct_count if clean_correct_count else 0.0,
                "confidence_shift": float(np.mean(np.abs(clean_proba - pert_proba))),
                **pert_metrics,
            }
        )
    return rows


def main() -> None:
    args = parse_args()
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)

    if torch.backends.mps.is_available():
        device = torch.device("mps")
    else:
        device = torch.device("cpu")
    print(f"Using device: {device}")

    reports_dir = args.output_dir / "reports"
    models_dir = args.output_dir / "models"
    reports_dir.mkdir(parents=True, exist_ok=True)
    models_dir.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(args.input_csv)
    train_full = df[df["split"].isin(["train", "val"])].copy()
    test_df = df[df["split"] == "test"].copy()

    all_rows = []
    for variant in args.train_variants:
        train_variant = make_training_frame(train_full, variant, args)
        vocab = build_vocab(train_variant["comment_text"].astype(str).tolist(), args.max_vocab_size)
        print(f"Training textcnn_{variant} on {len(train_variant)} rows, vocab={len(vocab)}")
        model = train_model(train_variant, vocab, args, device)
        model_name = f"textcnn_{variant}"
        all_rows.extend(evaluate_variant(model_name, model, vocab, test_df, args, device))
        if args.save_models:
            torch.save(
                {"state_dict": model.state_dict(), "vocab": vocab, "args": vars(args)},
                models_dir / f"{model_name}.pt",
            )

    metrics_df = pd.DataFrame(all_rows)
    metrics_path = reports_dir / "robustness_metrics.csv"
    metrics_df.to_csv(metrics_path, index=False)
    (reports_dir / "run_info.json").write_text(json.dumps(vars(args), indent=2, default=str), encoding="utf-8")
    print(metrics_df.to_string(index=False))
    print(f"\nSaved TextCNN metrics to {metrics_path}")


if __name__ == "__main__":
    main()
