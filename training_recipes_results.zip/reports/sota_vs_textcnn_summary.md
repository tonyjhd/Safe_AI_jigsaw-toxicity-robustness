# SOTA vs Project Model Comparison

## Setup

- SOTA reference: `unitary/unbiased-toxic-roberta`
- Project models: `textcnn_clean`, `textcnn_aug_100_targeted`
- Evaluation subset: balanced 1,000 samples from the Jigsaw test split
- Perturbations: `char_substitution`, `spacing`, `combined`
- Decision threshold: toxicity score >= 0.5

## Clean Performance

| model | accuracy | precision | recall | clean_f1 | auroc |
| --- | --- | --- | --- | --- | --- |
| sota_unbiased_roberta | 0.8530 | 0.9836 | 0.7180 | 0.8301 | 0.9868 |
| textcnn_clean | 0.8110 | 0.8008 | 0.8280 | 0.8142 | 0.9009 |
| textcnn_aug_100_targeted | 0.8230 | 0.8088 | 0.8460 | 0.8270 | 0.9040 |

## Robustness Summary

| model | perturbation | clean_f1 | perturbed_f1 | robustness_drop_f1 | attack_success_rate | auroc |
| --- | --- | --- | --- | --- | --- | --- |
| sota_unbiased_roberta | char_substitution | 0.8301 | 0.7414 | 0.0887 | 0.0797 | 0.9588 |
| sota_unbiased_roberta | spacing | 0.8301 | 0.7159 | 0.1141 | 0.0985 | 0.9457 |
| sota_unbiased_roberta | combined | 0.8301 | 0.7128 | 0.1172 | 0.1079 | 0.9344 |
| textcnn_clean | char_substitution | 0.8142 | 0.7649 | 0.0492 | 0.0925 | 0.8493 |
| textcnn_clean | spacing | 0.8142 | 0.7526 | 0.0615 | 0.0949 | 0.8363 |
| textcnn_clean | combined | 0.8142 | 0.7277 | 0.0865 | 0.1319 | 0.8307 |
| textcnn_aug_100_targeted | char_substitution | 0.8270 | 0.8118 | 0.0152 | 0.0401 | 0.8836 |
| textcnn_aug_100_targeted | spacing | 0.8270 | 0.8044 | 0.0226 | 0.0377 | 0.8819 |
| textcnn_aug_100_targeted | combined | 0.8270 | 0.7992 | 0.0278 | 0.0571 | 0.8807 |

## Key Takeaway

The public RoBERTa-based SOTA reference has strong clean performance, but it is still vulnerable to the exact obfuscation-style perturbations used in this project. The targeted augmented TextCNN is not a better general SOTA model, but it is more robust on this controlled perturbation test.

Most important comparison:

- SOTA combined F1 drop: 0.1172
- TextCNN clean combined F1 drop: 0.0865
- TextCNN targeted augmentation combined F1 drop: 0.0278
- SOTA combined ASR: 0.1079
- TextCNN targeted augmentation combined ASR: 0.0571

Use this wording in the final report:

> Compared with a public RoBERTa-based toxicity classifier, the targeted augmentation TextCNN achieved lower robustness drop and lower attack success rate under spacing and combined obfuscation attacks on the same balanced Jigsaw test subset. This suggests that robustness-targeted training can outperform a stronger clean classifier on the specific moderation-evasion threat model.

## Caveat

This is not an official Kaggle leaderboard comparison. The SOTA model was not fine-tuned on the exact augmented data used here, and the evaluation uses a balanced 1k subset plus custom perturbation attacks. Therefore the fair claim is about robustness under this threat model, not overall SOTA accuracy.
