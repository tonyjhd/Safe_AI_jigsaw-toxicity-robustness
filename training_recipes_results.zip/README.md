# Training Recipes and Results with Explanations

Project:

```text
Robustness Evaluation of Toxicity Detection Models under Text Perturbations
```

## 1. Research Question

Clean accuracy alone may not be enough for trustworthy toxicity moderation.

This project asks:

```text
Can a toxicity detector still identify toxic comments when users obfuscate toxic words?
```

Examples:

```text
idiot  -> i d i o t
hate   -> h@te
stupid -> stuupid
```

Humans can still understand the meaning, but model tokenization or text features may break.

## 2. Dataset Recipe

Source dataset:

```text
Jigsaw Unintended Bias in Toxicity Classification
```

Hugging Face mirror used:

```text
Intuit-GenSRF/jigsaw-unintended-bias
```

Binary label rule:

```text
target >= 0.5 -> label = 1 toxic
target < 0.5  -> label = 0 non-toxic
```

Balanced subset:

| Split | Non-toxic | Toxic | Total |
|---|---:|---:|---:|
| Train | 5,000 | 5,000 | 10,000 |
| Validation | 1,000 | 1,000 | 2,000 |
| Test | 1,000 | 1,000 | 2,000 |

Dataset export:

```text
Separate submission file: jigsaw_toxicity_robustness_shareable.zip
```

## 3. Perturbation Recipe

The perturbation generator changes the text surface form but keeps the label fixed.

| Perturbation | Example | Purpose |
|---|---|---|
| typo | `stupid -> stupdi` | Simulate normal typos |
| char_substitution | `hate -> h@te` | Simulate obfuscated toxic words |
| spacing | `idiot -> i d i o t` | Break tokenization |
| repetition | `bad -> baaad` | Simulate informal writing |
| punctuation_noise | `bad -> bad!!!` | Add punctuation noise |
| combined | `hate -> h @ t e` | Strong mixed perturbation |

Implementation:

```text
scripts/perturbations.py
```

## 4. Model Training Recipes

### 4.1 TF-IDF + MLP Baselines

Models:

```text
word_mlp
char_mlp
```

Recipe:

```text
TF-IDF
-> TruncatedSVD
-> StandardScaler
-> MLPClassifier
```

Main settings:

| Parameter | Value |
|---|---:|
| max_features | 50,000 |
| svd_components | 128 |
| hidden_size | 128 |
| epochs | 30 |
| augmentation fraction | 25% for augmented variant |
| seed | 42 |

### 4.2 TextCNN

Architecture:

```text
Embedding
-> Conv1D filters with kernel sizes [3, 4, 5]
-> Global max pooling
-> Dropout
-> Linear output
```

Stronger TextCNN settings:

| Parameter | Value |
|---|---:|
| max_vocab_size | 30,000 |
| max_len | 128 |
| embedding_dim | 96 |
| filters | 96 |
| dropout | 0.45 |
| epochs | 10 |
| batch_size | 128 |
| lr | 0.001 |
| seed | 42 |

Final targeted defense training:

```text
clean train + validation rows = 12,000
targeted perturbed copy       = 12,000
total training rows           = 24,000
```

Targeted augmentation types:

```text
spacing
combined
char_substitution
```

### 4.3 SOTA-style Reference

Public reference model:

```text
unitary/unbiased-toxic-roberta
```

URL:

```text
https://huggingface.co/unitary/unbiased-toxic-roberta
```

This model is used as a strong clean-performance reference. It was not trained by our team.

## 5. Evaluation Metrics

| Metric | Explanation | Better Direction |
|---|---|---|
| Clean F1 | F1 score on original clean text | Higher |
| Perturbed F1 | F1 score after perturbation | Higher |
| F1 Drop | Clean F1 - Perturbed F1 | Lower |
| ASR | Clean-correct samples that become wrong after perturbation | Lower |
| Toxic Recall Drop | Drop in recall on toxic-only samples | Lower |

## 6. Main Results

### 6.1 Baseline Robustness

| Model | Attack | Clean F1 | Perturbed F1 | F1 Drop | ASR |
|---|---|---:|---:|---:|---:|
| word_mlp | combined | 0.689 | 0.667 | 0.022 | 0.057 |
| char_mlp | spacing | 0.714 | 0.690 | 0.024 | 0.043 |
| TextCNN | combined | 0.708 | 0.669 | 0.039 | 0.145 |

Interpretation:

```text
All models degrade after perturbation. Clean F1 alone hides robustness failures.
```

### 6.2 General Perturbation Augmentation

| Model | Attack | Clean-only F1 Drop | Augmented F1 Drop | Improvement |
|---|---|---:|---:|---:|
| word_mlp | combined | 0.022 | 0.012 | 0.010 lower |
| char_mlp | spacing | 0.024 | 0.019 | 0.005 lower |
| TextCNN | combined | 0.039 | 0.015 | 0.024 lower |

Interpretation:

```text
Adding perturbed examples to training reduces robustness drop.
```

### 6.3 Stronger TextCNN Targeted Defense

| Variant | Attack | Clean F1 | Perturbed F1 | F1 Drop | ASR |
|---|---|---:|---:|---:|---:|
| clean_baseline | spacing | 0.8075 | 0.7372 | 0.0703 | 0.1001 |
| aug_100_targeted | spacing | 0.8315 | 0.8130 | 0.0185 | 0.0356 |
| clean_baseline | combined | 0.8075 | 0.7351 | 0.0724 | 0.1255 |
| aug_100_targeted | combined | 0.8315 | 0.8012 | 0.0303 | 0.0592 |

Key numbers:

```text
Spacing F1 drop:  0.0703 -> 0.0185
Combined F1 drop: 0.0724 -> 0.0303
Combined ASR:     0.1255 -> 0.0592
```

Interpretation:

```text
Targeted augmentation is more effective when it matches the actual threat model.
```

### 6.4 SOTA Reference Comparison

Clean performance on balanced 1,000-sample Jigsaw test subset:

| Model | Accuracy | Precision | Recall | Clean F1 | AUROC |
|---|---:|---:|---:|---:|---:|
| SOTA RoBERTa reference | 0.8530 | 0.9836 | 0.7180 | 0.8301 | 0.9868 |
| TextCNN clean | 0.8110 | 0.8008 | 0.8280 | 0.8142 | 0.9009 |
| TextCNN targeted augmentation | 0.8230 | 0.8088 | 0.8460 | 0.8270 | 0.9040 |

Robustness under perturbation:

| Model | Attack | Clean F1 | Perturbed F1 | F1 Drop | ASR |
|---|---|---:|---:|---:|---:|
| SOTA RoBERTa reference | combined | 0.8301 | 0.7128 | 0.1172 | 0.1079 |
| TextCNN clean | combined | 0.8142 | 0.7277 | 0.0865 | 0.1319 |
| TextCNN targeted augmentation | combined | 0.8270 | 0.7992 | 0.0278 | 0.0571 |

Interpretation:

```text
RoBERTa is stronger on clean data, especially AUROC.
However, targeted TextCNN has lower F1 drop and lower ASR under this specific obfuscation threat model.
```

Important caveat:

```text
This is not an official Kaggle leaderboard comparison.
This does not mean TextCNN is generally better than RoBERTa.
The claim is about robustness under this controlled text-obfuscation test.
```

## 7. Included Result Files

| Path | Description |
|---|---|
| `reports/all_model_robustness_metrics.csv` | Full baseline robustness metrics |
| `reports/defense_comparison.csv` | Clean vs augmented defense comparison |
| `reports/augmentation_ratio_summary.csv` | Augmentation ratio comparison |
| `reports/targeted_toxic_eval.csv` | Toxic-only targeted evaluation |
| `reports/textcnn_defense_variant_summary.csv` | Stronger TextCNN targeted defense summary |
| `reports/sota_vs_textcnn_summary.md` | SOTA reference comparison summary |
| `figures/baseline_f1_drop.png` | Baseline F1 drop figure |
| `figures/general_defense_before_after.png` | General defense before/after figure |
| `figures/textcnn_targeted_f1_drop.png` | Targeted TextCNN F1 drop figure |
| `figures/textcnn_targeted_asr.png` | Targeted TextCNN ASR figure |
| `figures/sota_clean_performance.png` | Clean SOTA comparison figure |
| `figures/sota_vs_textcnn_f1_drop.png` | SOTA vs TextCNN F1 drop figure |
| `figures/sota_vs_textcnn_asr.png` | SOTA vs TextCNN ASR figure |

## 8. Reproduction Commands

Prepare dataset:

```bash
python scripts/prepare_jigsaw_subset.py \
  --source hf_stream \
  --train-size 10000 \
  --val-size 2000 \
  --test-size 2000 \
  --output-csv data/processed/jigsaw_subset_14k_stratified.csv
```

Train TF-IDF + MLP baselines:

```bash
python scripts/train_evaluate_robustness.py \
  --input-csv data/processed/jigsaw_subset_14k_stratified.csv \
  --models word_mlp char_mlp \
  --train-variants clean augmented \
  --augmentation-fraction 0.25 \
  --augmentation-copies 1 \
  --augmentation-perturbations typo char_substitution spacing repetition combined \
  --epochs 30 \
  --svd-components 128 \
  --hidden-size 128 \
  --save-models
```

Train stronger targeted TextCNN:

```bash
python scripts/train_evaluate_textcnn.py \
  --input-csv data/processed/jigsaw_subset_14k_stratified.csv \
  --output-dir outputs/textcnn_stronger_defense/targeted_100 \
  --train-variants augmented \
  --augmentation-fraction 1.0 \
  --augmentation-perturbations spacing combined char_substitution \
  --epochs 10 \
  --embedding-dim 96 \
  --filters 96 \
  --dropout 0.45 \
  --batch-size 128 \
  --save-models
```

Evaluate SOTA reference:

```bash
python scripts/evaluate_sota_toxicity_model.py \
  --input-csv data/processed/jigsaw_subset_14k_stratified.csv \
  --output-dir outputs/sota_unbiased_roberta_1k \
  --model-id unitary/unbiased-toxic-roberta \
  --perturbations char_substitution spacing combined \
  --max-samples 1000 \
  --batch-size 16 \
  --max-length 192
```

## 9. Final Claim

```text
Clean performance alone is not enough for trustworthy toxicity detection.
Even a strong RoBERTa-based toxicity classifier can fail under simple text-obfuscation attacks.
Targeted perturbation augmentation reduces robustness drop and attack success rate.
```
